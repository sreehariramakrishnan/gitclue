import { DocumentVault } from "../DocumentVault";

export default function DocumentVaultExample() {
  return (
    <div className="p-8 max-w-6xl mx-auto">
      <DocumentVault />
    </div>
  );
}
